sailsProject
============

a [Sails](http://sailsjs.org) application

gem install
-----------

`gem install bootstrap-sass compass font-awesome-sass`

start with Docker
-----------------

```
docker-compose up mysql -d
docker-compose up web -d
```
